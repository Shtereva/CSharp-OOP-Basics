﻿using System;

public class Validator
{
    public static void GetValidation(string type, string foodType)
    {
        Console.WriteLine($"{type} does not eat {foodType}!");
    }
}