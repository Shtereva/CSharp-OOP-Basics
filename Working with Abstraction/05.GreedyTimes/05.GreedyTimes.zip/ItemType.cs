﻿public enum ItemType
{
    Gold,
    Gem,
    Cash
}
