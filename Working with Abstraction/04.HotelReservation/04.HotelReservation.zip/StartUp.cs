﻿using System;

public class StartUp
{
    public static void Main()
    {
        PriceCalculator.CalculateTotalPriseForHoliday(Console.ReadLine());
    }
}
