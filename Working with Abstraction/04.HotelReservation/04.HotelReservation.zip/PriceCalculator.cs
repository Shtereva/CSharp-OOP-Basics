﻿using System;

public static class PriceCalculator
{
    public static void CalculateTotalPriseForHoliday(string input)
    {
        var args = input.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

        decimal pricePerDay = decimal.Parse(args[0]);
        int numberOfDays = int.Parse(args[1]);
        string season = args[2];
        string discountType = args.Length > 3 ? args[3] : String.Empty;

        int multiplier = SelectMultiplier(season);
        int discount = SelectDiscount(discountType);

        decimal totalSum = (pricePerDay * numberOfDays) * multiplier;
        Console.WriteLine($"{totalSum - (totalSum * ((decimal)discount / 100)):f2}");
    }

    private static int SelectDiscount(string discountType)
    {
        if (Enum.GetName(typeof(DiscountType), DiscountType.VIP) == discountType)
        {
            return 20;
        }

        else if (Enum.GetName(typeof(DiscountType), DiscountType.SecondVisit) == discountType)
        {
            return 10;
        }

        return 0;
    }

    private static int SelectMultiplier(string season)
    {
        if (Enum.GetName(typeof(Season), Season.Autumn) == season)
        {
            return 1;
        }

        else if (Enum.GetName(typeof(Season), Season.Spring) == season)
        {
            return 2;
        }

        else if (Enum.GetName(typeof(Season), Season.Winter) == season)
        {
            return 3;
        }

        return 4;
    }
}
