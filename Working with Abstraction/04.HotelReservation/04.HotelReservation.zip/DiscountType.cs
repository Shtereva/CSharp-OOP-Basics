﻿public enum DiscountType
{
    VIP,
    SecondVisit,
    None
}
