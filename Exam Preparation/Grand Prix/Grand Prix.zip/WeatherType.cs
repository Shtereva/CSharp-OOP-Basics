﻿public enum WeatherType
{
    Rainy,
    Foggy,
    Sunny
}
