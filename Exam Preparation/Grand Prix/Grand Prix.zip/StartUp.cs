﻿public class StartUp
{
    public static void Main()
    {
        var parser = new CommandParser();
        parser.Execute();
    }
}
