﻿public class StartUp
{
    static void Main()
    {
        var parser = new CommandParser();
        parser.Execute();
    }
}
