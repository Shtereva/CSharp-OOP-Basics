﻿    public enum ModeType
    {
        Full,
        Half,
        Energy
    }
